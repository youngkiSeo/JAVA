package com.green.java.ch07;

public class ModifierTest {
    private int num1;
    int num2;
    protected int num3;
    public int num4;

    public void printNum1() {
        System.out.println(num1);
    }
}