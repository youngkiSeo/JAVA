//package com.green.java.ch07.abstract2;
//
//public class FighterTest implements Fightable{
//    public static void main(String[] args) {
//        Fightable f1 = new Fighter();
//        Fightable f2 = new Fighter();
//
//        f1.sum(10, 20);
//        f1.move(19, 21);
//
//
//        f2.sum(30, 40);
//        f1.move(29, 41);
//
//    }
//    }

