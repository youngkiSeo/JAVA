package com.green.java.ch07;

public class GrandChild extends Child {

    public GrandChild() {
        System.out.println("-- GrandChild 기본 생성자 --");
    }




}
