//package com.green.java.practice;
//
//public class End /*
//최상의 클래스 = 오브젝트
//인터페이스 = 인플리먼츠 (구현) 통해서 상속받음
//인터페이스 <-> 인터페이스 상속가능 , 익스텐즈 사용
//
//
//
//}
