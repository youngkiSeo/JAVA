package com.green.java.ch03;

public class OperatorStudy03 {
    public static void main(String[] args) {
        int r = -3 -5; // int r = -3 - +5;
        System.out.println(r);
        int r2 = +5 - +3; // + 양수는 생략해도 됨
        System.out.println(r2);

        int r3 = -3 + 5; // + 양수는 생략해도 됨
        System.out.println(r3);
    }
}
