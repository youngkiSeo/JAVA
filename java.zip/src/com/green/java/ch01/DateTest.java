package com.green.java.ch01;

public class DateTest {
    public static void main(String[] args) {
        int y = 2023, m=4, d=27;
        String strDate = String.format("%d-%02d-%d", y, m, d);
        System.out.println(strDate);// "2023-05-27"




//        m=12;
//        d=5;
//
//
//
//        "2023-04-27"
    }
}
