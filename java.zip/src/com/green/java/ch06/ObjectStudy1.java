package com.green.java.ch06;

public class ObjectStudy1 {
    public static void main(String[] args) {
        //클래스(class) : 붕어빵틀, 설계도
        //객체 (object): (인스턴스, Instance)붕어빵, 클래스로 만든 실체
        //객체 2가지 구성요소: 멤버필드(변수, 상수)(속성), 멤버메소드
        //멤버필드 명사 담당, 값 저장 가능
        //멤버메소드 동사 담당, 동작 담당.
        //e.g. 게임 캐릭터, 멤버필드 > 직업, 이름, 레벨, hp, mp, 스테니마
        //              , 멤버 메소드> 이동한다, 아이템 줍는다. 아이템 버린다, 공격한다

        //Method(메소드), Function(함수)
        //객체안에 존재하면 메소드
        //객체밖에 존재하면 함수

        // stack 메모리 FILO first in last out: 변수
        // heap 메모리 FIFO first in first out: 객체
    }
}