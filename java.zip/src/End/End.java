
/*
ch01
JDK : Java develop kit
JRE : Java runtime envionment

printf: 출력하는게 목적
String result = String.format: 문자열을 만들어서 UI에서 출력하는 것이 목적{



 */

