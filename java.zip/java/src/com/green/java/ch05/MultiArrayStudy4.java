package com.green.java.ch05;

public class MultiArrayStudy4 {
    public static void main(String[] args) {

        }
    }


