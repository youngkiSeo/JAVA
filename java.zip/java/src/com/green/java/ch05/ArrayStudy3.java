package com.green.java.ch05;

public class ArrayStudy3 {
    public static void main(String[] args) {
        int[] numArr = new int[] { 1, 2, 3, 4, 5 };
    }
}
