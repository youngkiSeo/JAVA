package com.green.java.ch03;

public class OperatorStudy04 {
    public static void main(String[] args) {
        int num = 5;

        //num = num - 10l
        //num = num * -1;
        num = -num;

        System.out.println(num);
    }
}
