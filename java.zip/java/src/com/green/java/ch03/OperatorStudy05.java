package com.green.java.ch03;

public class OperatorStudy05 {
    public static void main(String[] args) {
        int num = -5;

        num = num + 10;
        //num = num * 1;
        // num = -num;

        System.out.println(num);
    }
}
