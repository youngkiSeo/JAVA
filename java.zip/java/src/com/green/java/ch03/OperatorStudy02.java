package com.green.java.ch03;

public class OperatorStudy02 {
    public static void main(String[] args) {
        int num = 10;
        int result = num % 2;
        System.out.printf("%d %% 2 = %d\n", num, result);

        num = 9;
        result = num % 2;
        System.out.printf("%d %% 2 = %d\n", num, result);



    }
}
