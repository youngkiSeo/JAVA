package com.green.java.ch03;

public class OperatorStudy06 {
    public static void main(String[] args) {
        int n1, n2, val = 10;

        n1 = n2 = val; // 오른쪽 값부터 설정됨, n2 <-10, n1 <-n2

        System.out.println(n1);
        System.out.println(n2);
        System.out.println(val);
    }
}
