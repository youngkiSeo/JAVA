package com.green.java.ch03; // p.105

public class OperatorEx21 {
    public static void main(String[] args) {
        System.out.printf("10 == 10.0f \t %b\n", 10 == 10.0f);
        // \t= 라인 맞추기, %b = 불린타입
        System.out.printf("'0' == 0 \t %b\n", '0' == 0);

        System.out.printf("'A' == 65 \t %b\n", 'A' == 65);
        System.out.printf("'A' + 1 == 'b' \t %b\n", 'A' + 1 == 'B');
        System.out.printf("'A' + 1 ! 'C' \t %b\n", 'A' + 1 !='C');
        // '!' 같지 않니 물어보는 것





    }
}

