package com.green.java.baekjoon;

public class b25206 {
    public static void main(String[] args) {

    }
}
