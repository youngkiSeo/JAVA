package com.green.java.baekjoon;

import java.util.Scanner;

public class baekjoon_8393 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int a=0;
        int n = scan.nextInt();
        for(int i = 0; i<=n; i++){
            a=a+i;



        }
        System.out.println(a);



    }
}
