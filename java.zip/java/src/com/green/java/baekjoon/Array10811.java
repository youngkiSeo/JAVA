package com.green.java.baekjoon;

import java.util.Scanner;

public class Array10811 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int input = scan.nextInt();
        int [] basket = new int [input];
    }
}
