package com.green.java.baekjoon;

import java.util.Scanner;

public class b11718 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        while (true) {
            String str = scan.next();
            System.out.println(str);
        }
    }

}
