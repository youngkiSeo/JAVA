package com.green.java.baekjoon;

import java.util.Scanner;

public class baekjoon_25314 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int input= scan.nextInt();
        int a=input/4;
        for(int i=0;i<a;i++){
            System.out.print("long ");
        }
        System.out.println(" int");

    }
}
