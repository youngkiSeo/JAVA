package com.green.java.ch07.abstract2;

public interface CanFly {
    void fly();

}
