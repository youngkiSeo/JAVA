package com.green.java.ch07;

public class Parent extends Object{
    int age;

    public Parent(){
        super();
        System.out.println("-- Parent 기본 생성자 --");
    }
}