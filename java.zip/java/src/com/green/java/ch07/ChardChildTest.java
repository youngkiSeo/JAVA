package com.green.java.ch07;

public class ChardChildTest {
    public static void main(String[] args) {
        GrandChild gc = new GrandChild();
    }
}
