package com.green.java.ch07.ArrayList;

public class MyArrayListTest2 {
    public static void main(String[] args) {
        MyArrayList mylist = new MyArrayList();
        mylist.add(10);
        mylist.add(22);
        mylist.add(4);
        mylist.add(200);
        mylist.add(53);
        mylist.add(96);
        mylist.bubbleStart();
    }
}
