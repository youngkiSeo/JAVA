package com.green.java.ch07;
public class test {
    public static void main(String[] args) {
        System.out.println("안녕하세요");
    }
}