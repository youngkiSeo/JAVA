package com.green.java.blackjack;

public class CardTest {
    public static void main(String[] args) {
    CardDeck cd = new CardDeck();
        cd.showSize();
        Card c = cd.getCard();
        cd.showSize();
    }


}
