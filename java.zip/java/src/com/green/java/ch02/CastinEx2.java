package com.green.java.ch02;

public class CastinEx2 {

    public static void main(String[] args) {
        int n1 = 10;
        int n2 = 3;

        double rr = 10L;
        double r = (double)n1 / n2;
        System.out.println(r);
        System.out.println((double) n1/n2);

        System.out.printf("%.3f\n", r);

        double d1 = (double) n1;
        double d2 = (double) n2;





        System.out.println(n1/n2);

    }
}