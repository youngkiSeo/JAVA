package com.green.java.ch02;

public class VariableBoolean {
    public static void main(String[] args) {
        boolean b1 = true, b2 = false;
        System.out.println(b1);
        System.out.println(b2);

        b2 = 10 > 2;
        b2 = true;
        System.out.println(b2);


    }
}
