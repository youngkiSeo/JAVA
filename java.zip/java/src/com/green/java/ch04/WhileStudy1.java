package com.green.java.ch04;

import java.util.Scanner;

public class WhileStudy1 {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            System.out.println("for");
        }
        System.out.println("--------");

        int i = 0;
        while(i<5) {
            System.out.println("while");
            i++;

        }
    }

}
