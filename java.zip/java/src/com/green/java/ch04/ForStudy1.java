
package com.green.java.ch04;

public class ForStudy1 {
    public static void main(String[] args) {
        // for(   ;   ;   )
//        for(int i=21; i>17; i--) { // 4
//            System.out.println("A");
//        }

        for(int i=5; i<10; i++) {
            System.out.print((i - 4));
            System.out.print(", ");

        }
        //5 6 7 8 9
        //1 2 3 4 5
    }
}