package com.green.java.ch04;

public class WhileStudy2 {
    public static void main(String[] args) {
        //do-while문

        do {

        } while(false);


        while(true) {

        }


    }
}
