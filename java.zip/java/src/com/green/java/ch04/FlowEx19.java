package com.green.java.ch04;

public class FlowEx19 {
    public static void main(String[] args) {
        for(int i=1; i<4; i++){
            for(int z=1; z<4; z++){
                for(int y=1; y<4; y++){
                    System.out.println(""+i+z+y);
                }
            }
        }
    }
}
