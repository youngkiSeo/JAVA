package com.green.java.ioc;

public interface Speaker {
    void volumeUp();
    void volumeDown();
}
