package com.green.java.ioc;

public interface Woofer {
    void sound();

}
