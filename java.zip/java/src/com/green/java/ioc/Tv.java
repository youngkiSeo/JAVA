package com.green.java.ioc;

public interface Tv {
    void turnOn();
    void turnOff();
}