package com.green.java.ch06;

public class MyMathstatic {
    public static int sum(int n1, int n2){
        return n1+n2;
    }
}
