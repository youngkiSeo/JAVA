package com.green.java.ch06;

public class Mymethod {

    // void -> return type 리턴타입
    // sum > method name , 메소드 명
    //(int n1, int2) ->parameter 파라미터 매개변수

    //void 메소드
    void sum(int n1, int n2){ //선언부
        System.out.println(n1 + n2);
    } //구현부

    //리턴 메소드
    int sum2(int n1, int n2){
        return n1 +n2;
    }
}
