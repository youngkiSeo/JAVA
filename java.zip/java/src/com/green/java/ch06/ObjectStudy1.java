package com.green.java.ch06;

import java.lang.reflect.Method;

public class ObjectStudy1 {
    public static void main(String[] args) {
        //클래스 class 붕어빵 틀
        //객체(object): (인스턴스,instance)클래스로 만든 실체
        //객체 2가지 구성요소 맴버필드,메소드
        /*
        맴버필드 명사 담당, 값저장 기능
        맴버 메소드 동사담당, 동작담당
        객체 안에 존재하면 메소드 Method
        객체밖에 존재하면 함수 Function
        자바는 class안에 함수넣어야함
         */


    }
}
