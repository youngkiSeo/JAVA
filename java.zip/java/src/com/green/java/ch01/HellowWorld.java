package com.green.java.ch01;


public class HellowWorld {
    public static void main(String[] args) {
        // 주석
        // single line comments
        /*
        multi line comments

         */
        System.out.println("Hello World!");
        // println만 계행해줌
        // print, printf는 계행안해줌


    }
}
